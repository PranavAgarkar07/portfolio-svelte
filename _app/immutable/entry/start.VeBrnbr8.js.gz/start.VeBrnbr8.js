import{l as o,a as r}from"../chunks/DXJwIT6J.js";export{o as load_css,r as start};
