import{l as o,a as r}from"../chunks/DSe512D3.js";export{o as load_css,r as start};
