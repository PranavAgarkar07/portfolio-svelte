import{l as o,a as r}from"../chunks/DYk_qTC5.js";export{o as load_css,r as start};
